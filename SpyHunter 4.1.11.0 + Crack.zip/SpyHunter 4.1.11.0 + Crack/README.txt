Installation:
1. Install program (do not run!!)

2. Copy crack to install folder overwriting original

3. All done! Enjoy

Credits goes to Dazz!! Thanks Mate!!
